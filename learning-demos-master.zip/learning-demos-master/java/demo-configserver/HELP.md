# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Centralized Configuration](https://spring.io/guides/gs/centralized-configuration/)

